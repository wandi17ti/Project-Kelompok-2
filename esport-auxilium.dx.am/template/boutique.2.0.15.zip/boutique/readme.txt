=== Boutique ===
Contributors:      automattic, jameskoster, tiagonoronha
Tags:              e-commerce, light, dark, two-columns, right-sidebar, responsive-layout, accessibility-ready
Requires at least: 4.0
Tested up to:      4.9.2
Stable tag:        2.0.14
License:           GPLv2 or later
Image License:     GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

A Storefront child theme designed for small WooCommerce stores / boutiques. *Boutique* features a simple, traditional design which you can customise using the settings available in the WordPress Customizer. Looking for a theme for your new WooCommerce store? Look no further than Storefront and Boutique!

== Description ==

Storefront is a robust and flexible WordPress theme, designed by WooCommerce creators WooThemes to help you make the most out of using WooCommerce to power your online store. It's available to download for free at the WordPress theme repository.

Boutique is a child theme for Storefront meaning that both themes must be installed if you want to run Boutique on your store.
